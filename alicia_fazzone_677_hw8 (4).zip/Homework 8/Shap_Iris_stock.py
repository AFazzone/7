
from sklearn.metrics import accuracy_score
import pandas as pd
import numpy as np
import matplotlib . pyplot as plt
from matplotlib . ticker import MaxNLocator
import seaborn as sns
import os
import collections
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import svm, datasets
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn . metrics import mean_squared_error , r2_score


# Import CSV
FDX_weeks = pd.read_csv("FDX_Weeks_labels.csv") 

# Create Dataframes
FDX_weeks_df  = pd.DataFrame(FDX_weeks)

#Filter dataframe by year
FDX_2015 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2015])]
FDX_2016 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2016])]



#KNN Assignment

xtrain_k3 = FDX_2015[["mean_return", "volatility"]]
ytrain_k3 = FDX_2015[["Label"]]


x_test = FDX_2016[["mean_return", "volatility"]]
y_test = FDX_2016[["Label"]]
ytest_close = FDX_2016[["Close"]]

y_test_list = FDX_2016["Label"].tolist() 

#Run the classifier for both

scaler = StandardScaler().fit(xtrain_k3)
train_k3= scaler.transform(xtrain_k3)


knn_classifier = KNeighborsClassifier(n_neighbors =3)
knn_classifier.fit(xtrain_k3,np.ravel(ytrain_k3))
pred_k3 = knn_classifier.predict (x_test)
conf_k3 = confusion_matrix(y_test_list, pred_k3, ["Green", "Red"])
k3_accuracy = knn_classifier.score (xtrain_k3, np.ravel(ytrain_k3))

print("KNN Both", k3_accuracy)


#Run for mean
xtrain_mean = FDX_2015[["mean_return"]]
x_test_mean = FDX_2016[["mean_return"]]

knn_classifier = KNeighborsClassifier(n_neighbors =3)
knn_classifier.fit(xtrain_mean,np.ravel(ytrain_k3))
pred_k3 = knn_classifier.predict (x_test_mean)
conf_k3 = confusion_matrix(y_test_list, pred_k3, ["Green", "Red"])
mean_accuracy = knn_classifier.score (xtrain_mean, np.ravel(ytrain_k3))

print("KNN Mean", mean_accuracy)

#Run for Volitility

xtrain_vol = FDX_2015[["volatility"]]
x_test_vol = FDX_2016[["volatility"]]

knn_classifier = KNeighborsClassifier(n_neighbors =3)
knn_classifier.fit(xtrain_vol,np.ravel(ytrain_k3))
pred_k3 = knn_classifier.predict (x_test_vol)
conf_k3 = confusion_matrix(y_test_list, pred_k3, ["Green", "Red"])
vol_accuracy = knn_classifier.score (xtrain_vol, np.ravel(ytrain_k3))


print("KNN Volitility", vol_accuracy)




# Make series week number and close price for year 1
vol = FDX_2015["volatility"]
mn = FDX_2015["mean_return"]
close_price = FDX_2015["Close"]
label_2015 = FDX_2015["Label"]

x = np.array(vol)
y = np.array(close_price)
z = np.array(mn)
q = np.array(vol, mn)
a = label_2015.tolist()

#Model for linear


def linear(x,y,label):
    degree = 1
    weights = np. polyfit (x,y,degree )
    model = np. poly1d (weights)
    predicted = model (x)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    z=1
    for e in predicted:
        if z < 49:
            if predicted[z+1] < predicted[z]:
                label.append("Red")
            else:
                label.append("Green")
            z = z +1
    return(label)

both_label = []
vol_label = []
mean_label = []

linear(q, y, both_label)
linear(x, y, vol_label)
linear(z, y, mean_label)


#Compute accuracy

def accuracy(x,y):
    i = 0
    z = 0
    for e in x:
        if x[i] == y[i]:
            z = z+1
        i=i+1
    return(z/len(x))



#Run accuracy function

print("Both Linear:", (accuracy(both_label,a)))
print("Volatility Linear:",(accuracy(vol_label,a)))
print("Mean Linear:",(accuracy(mean_label,a)))


#Logistic

def logistic(a,b,c,d):
    a = a.values
    b = b.values
    c = c.values
    d = d.values
    log_reg_classifier = LogisticRegression ()
    log_reg_classifier . fit ( a, b)
    prediction = log_reg_classifier . predict ( c)
    accuracy = np. mean ( prediction == d)
    return(accuracy)

both_log = logistic(xtrain_k3, ytrain_k3, x_test, y_test)
mean_log = logistic(xtrain_mean, ytrain_k3, x_test_mean, y_test)
vol_log = logistic(xtrain_vol, ytrain_k3, x_test_vol, y_test)

print("Logistic Both:", both_log)
print("Logistic Volatility:", vol_log)
print("Logistic Mean:", mean_log)




# Question 2

# Import CSV
Iris_data = pd.read_csv("iris.csv") 

# Create Dataframes
iris = pd.DataFrame(Iris_data)

#Funtion to create binary label for flower type

def flower_type_label(x,y):
    ftype = []
    x = x.values
    for e in x:
        if e == y:
            ftype.append(0)
        else:
            ftype.append(1)
    return(ftype)
            
       


#Filter dataframe by feature
all_features = iris[["sepal_width","petal_length","petal_width"]]
slength = iris[["sepal_length"]]
swidth = iris[["sepal_width"]]
plength = iris[["petal_length"]]
pwidth = iris[["petal_width"]]
species = iris[["species"]]


#Create binary values for flower type
setosa = flower_type_label(species, "setosa")
versicolor = flower_type_label(species, "versicolor")
virginica = flower_type_label(species, "virginica")

#Add columns back to dataframe

iris["setosa"]  = setosa
iris["versicolor"] = versicolor
iris["virginica"] = virginica



#Run Logistic for each

def flogistic(x,y):
    x = x.values
    le = LabelEncoder ()
    y= le. fit_transform ( y )
    a,b,c,d= train_test_split (x,y,test_size =0.5 , random_state =3)
    log_reg_classifier = LogisticRegression ()
    log_reg_classifier . fit ( a, c)
    prediction = log_reg_classifier . predict ( b)
    accuracy = np. mean ( prediction == d)
    return(accuracy)



print("All logistic sestosa", flogistic(all_features,setosa ))
print("All logistic versicolor", flogistic(all_features,versicolor ))
print("All logistic virginica", flogistic(all_features,virginica ))


print("Sepal Length logistic sestosa", flogistic(slength,setosa ))
print("Sepal Length versicolor", flogistic(slength,versicolor ))
print("Sepal Length virginica", flogistic(slength,virginica ))


print("Sepal width logistic sestosa", flogistic(swidth,setosa ))
print("Sepal width versicolor", flogistic(swidth,versicolor ))
print("Sepal width virginica", flogistic(swidth,virginica ))


print("Petal width logistic sestosa", flogistic(swidth,setosa ))
print("Petal width versicolor", flogistic(swidth,versicolor ))
print("Petal width virginica", flogistic(swidth,virginica ))

print("Petal length logistic sestosa", flogistic(plength,setosa ))
print("Petal length versicolor", flogistic(plength,versicolor ))
print("Petal length virginica", flogistic(plength,virginica ))


