
import pandas as pd
import numpy as np



# Import CSV
tips = pd.read_csv("tips.csv") 

#Create dataframe
tips_df = df = pd.DataFrame(tips)

print("Question 1")

#Create a column for the tip percentage
tips_df["percent"] = tips_df["total_bill"]/tips_df["tip"]


#Split into lunch and dinner
dinner_df = tips_df[(tips_df["time"] == "Dinner")]
lunch_df = tips_df[(tips_df["time"] == "Lunch")]


print("Average Lunch percentage is", lunch_df["percent"].mean())
print("Average Dinner percentage is", dinner_df["percent"].mean())

print("Question 2")

#Split on days

thursday = tips_df[(tips_df["day"] == "Thur")]
friday = tips_df[(tips_df["day"] == "Fri")]
saturday = tips_df[(tips_df["day"] == "Sat")]
sunday = tips_df[(tips_df["day"] == "Sun")]


print("Average Thursday percentage is", thursday["percent"].mean())
print("Average Friday percentage is", friday["percent"].mean())
print("Average Saturday percentage is", saturday["percent"].mean())
print("Average Sunday percentage is", sunday["percent"].mean())
 

print("Question 3")

dinner_day = dinner_df[["day", "percent"]]
lunch_day = lunch_df[["day", "percent"]]

print("Dinner", dinner_day.groupby(["day"]).mean())
print("Lunch", lunch_day.groupby(["day"]).mean())

print("Question 4")

prices = tips_df["total_bill"]
tip = tips_df["tip"]

print("The correlation of bill price to tips is", prices.corr(tip))

print("Question 5")

group = tips_df["size"]

print("The correlation of group size price to tips is", group.corr(tip))


print("Question 6")

smoke = tips_df["smoker"]

print("Smokers", tips_df["smoker"].value_counts())
print("The percentage of smokers is ", 93/(151+93))



print("Question 7")

print("Thrusday first " , thursday["percent"].head(3),"last ", thursday["percent"].tail(3))
print("Friday first " , friday["percent"].head(3),"last ", friday["percent"].tail(3))
print("Saturday first " , saturday["percent"].head(3),"last ", saturday["percent"].tail(3))
print("Sunday first " , sunday["percent"].head(3),"last ", sunday["percent"].tail(3))

print("Question 8")

smoke = tips_df[tips_df["smoker"]  == 'Yes']
non = tips_df[tips_df["smoker"]  == 'No']

print("Average percent of smokers", smoke["percent"].mean())
print("Average percent of non-smokers", non["percent"].mean())













