# -*- coding: utf-8 -*-
"""
Created on Wed Dec  2 20:28:01 2020

@author: alf11
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
import os
from sklearn import datasets 
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from scipy.cluster.hierarchy import dendrogram, linkage
from sklearn.cluster import DBSCAN
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
import math


scaler = StandardScaler()


# Import CSV
FDX_weeks = pd.read_csv("FDX_Weeks_labels.csv") 

# Create Dataframes
FDX_weeks_df  = pd.DataFrame(FDX_weeks)


x = np.array(FDX_weeks_df[["mean_return", "volatility"]].values.ravel())
y = np.array(FDX_weeks_df[["Label"]].values.ravel())


x2 = list(np.array(FDX_weeks_df[["mean_return"]].values))
y2 = list(np.array(FDX_weeks_df[["volatility"]].values))


scaled_featuresx = scaler.fit_transform(x2)
scaled_featuresy = scaler.fit_transform(y2)


x = x.reshape(50,-1)

sse = []
for k in range(1,9):
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(x)
    sse.append(kmeans.inertia_)


#Question 1
print("SSE for K", sse)

#Plot SSE vs K to find elbow
x1 = [1,2,3,4,5,6,7,8]
y1 = sse
plt.plot(x1, y1, label = 'K Means SSE')
plt.xlabel('K')
# Set the y axis label of the current axis.
plt.ylabel('SSE')
# Set a title of the current axes.
plt.title('K Means SSE')
# show a legend on the plot
plt.legend()
# Display a figure.
plt.show()




df = pd.DataFrame({'x': x2,'y': y2})

#Run Classifier on 3 clusters

kmeans = KMeans(n_clusters=3)
kmeans.fit(df)
labels = kmeans.predict(df)
centroids = kmeans.cluster_centers_


print("Centroids are:",centroids)

#Put the labels of each group into a list

a = []
b = []
c = []

def cluster_group(x,y,a,b,c):
    i = 0
    for e in x:
        if e == 0:
            a.append(y[i])
            i = i+1
        elif e == 1:
            b.append(y[i])
            i = i+1
        elif e == 2:
            c.append(y[i])
            i = i +1
    return(a,b,c)

group1, group2, group3 = cluster_group(labels,y,a,b,c)
            
print("Cluster 1 is:", group1)
print("Cluster 2 is:", group2)
print("Cluster 3 is:", group3)

#Finding percentage of cluster 2
green = 0
red = 0

for e in group1:
    if e == "Green":
        green = green+1
    if e == "Red":
        red = red +1

print("Group two lengnth is ", len(group1), "Red", red, " Green", green)
