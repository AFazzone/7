# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 13:49:27 2020

@author: alf11
"""


import pandas as pd
import numpy as np
from sklearn . discriminant_analysis import LinearDiscriminantAnalysis as LDA
from sklearn . preprocessing import StandardScaler
from sklearn . discriminant_analysis import QuadraticDiscriminantAnalysis as QDA



# Import CSV
FDX_weeks = pd.read_csv("FDX_Weeks_labels.csv") 

# Create Dataframes
FDX_weeks_df  = pd.DataFrame(FDX_weeks)

#create test  and train sets
FDX_2015 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2015])]
FDX_2016 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2016])]


X = np.array(FDX_2015[["mean_return", "volatility"]].values.ravel())
Y = np.array(FDX_2015[["Label"]].values.ravel())

X = X.reshape(50,-1)
scaler = StandardScaler ()
scaler .fit(X)
X = scaler . transform (X)


X_test = np.array(FDX_2016[["mean_return", "volatility"]].values.ravel())
Y_test = np.array(FDX_2016[["Label"]].values.ravel())

X_test = X_test.reshape(50,-1)


# Linear Discriminant Classifier
lda_classifier = LDA( n_components = 0 )
model = lda_classifier . fit (X,Y)
new_x = scaler . transform (np. asmatrix ([2,50]))
predicted1 = lda_classifier . predict ( new_x )
accuracy1 = lda_classifier . score (X, Y)

print("Question 1:")
print("Linear  Coefficients:", lda_classifier.coef_)

#Quadratic Discriminant Classifier

qda_classifier = QDA ()
qda_classifier . fit ( X , Y)
prediction2 = lda_classifier . predict ( X_test )
accuracy2 = np. mean ( prediction2 == Y_test )


print("Question 2:")


print("Linear accuracy:", accuracy1)
print("Quadratic accuracy:", accuracy2)



print("Question 3:")

#Function for confusion matrix

def confusion (x,y):
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    i=0
    for e in x: 
        if x[i] == "Green":
            if x[i] == y[i]:
                tp = tp +1
            else:
                fp = fp +1
        else:
            if x[i] == y[i]:
                tn = tn + 1
            else: 
                fn = fn +1
        i = i+1
    return("Confusion:  TP", tp, "FP", fp, "TN", tn, "FN", fn)



#print("Linear confusion matrix is ", confusion(Y_test, predicted1))
print("Quadratic confusion matrix is ", confusion(Y_test, prediction2))



#Function for strategy

def strategy(x,a):
    value = 100
    z = 0
    for e in a:
        if e == "Green":
            value = value + ((value * x[z])/100)
        z = z + 1
    return (value)

rate = np.array(FDX_2016[["Return"]].values.ravel())

print("The strategy value is ", strategy(rate, prediction2) )

#calculate buy and hold
buy_hold = []
buy_hold_value = 100
i = 0
for e in rate:
    buy_hold_value = buy_hold_value + (buy_hold_value * (e/100))
    buy_hold.append(buy_hold_value)
    i = i + 1

print("The buy and hold value is ", buy_hold[-1])





