# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 12:50:15 2020

@author: alf11
"""
import numpy as np
import pandas as pd
from sklearn . ensemble import RandomForestClassifier
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 unused import

import matplotlib.pyplot as plt


# Import CSV
FDX_weeks = pd.read_csv("FDX_Weeks_labels.csv") 

# Create Dataframes
FDX_weeks_df  = pd.DataFrame(FDX_weeks)

#create test  and train sets
FDX_2015 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2015])]
FDX_2016 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2016])]


X = np.array(FDX_2015[["mean_return", "volatility"]].values.ravel())
Y = np.array(FDX_2015[["Label"]].values.ravel())

X = X.reshape(50,-1)


X_test = np.array(FDX_2016[["mean_return", "volatility"]].values.ravel())
Y_test = np.array(FDX_2016[["Label"]].values.ravel())

X_test = X_test.reshape(50,-1)

#Run Classifier
def r_forest (X,Y, X_test, Y_test, n, d):
    model = RandomForestClassifier ( n_estimators = n , max_depth = d ,
    criterion ='entropy')
    model . fit ( X , Y)
    prediction = model . predict ( X_test )
    error_rate = np. mean ( prediction != Y_test )
    return(error_rate)

#returns prediction
def p_forest (X,Y, X_test, Y_test, n, d):
    model = RandomForestClassifier ( n_estimators = n , max_depth = d ,
    criterion ='entropy')
    model . fit ( X , Y)
    prediction = model . predict ( X_test )
    error_rate = np. mean ( prediction != Y_test )
    return(prediction)



print("Question 1 Error rates")
print("N = 1, D = 1, E = ", r_forest(X,Y, X_test, Y_test, 1,1))
print("N = 1, D = 2, E = ", r_forest(X,Y, X_test, Y_test, 1,2))
print("N = 1, D = 3 , E = ", r_forest(X,Y, X_test, Y_test, 1,3))
print("N = 1, D = 4, E = ", r_forest(X,Y, X_test, Y_test, 1,4))
print("N = 1, D = 5, E = ", r_forest(X,Y, X_test, Y_test, 1,5))
      
print("N = 2, D = 1, E = ", r_forest(X,Y, X_test,Y_test, 2,1))
print("N = 2, D = 2, E = ", r_forest(X,Y, X_test,Y_test, 2,2))
print("N = 2, D = 3, E = ", r_forest(X,Y, X_test, Y_test,2,3))
print("N = 2, D = 4, E = ", r_forest(X,Y, X_test, Y_test,2,4))
print("N = 2, D = 5, E = ", r_forest(X,Y, X_test, Y_test,2,5))
                  
print("N = 3, D = 1, E = ", r_forest(X,Y, X_test,Y_test, 3,1))
print("N = 3, D = 2, E = ", r_forest(X,Y, X_test, Y_test,3,2))
print("N = 3, D = 3, E = ", r_forest(X,Y, X_test, Y_test,3,3))
print("N = 3, D = 4, E = ", r_forest(X,Y, X_test,Y_test, 3,4))
print("N = 3, D = 5, E = ", r_forest(X,Y, X_test, Y_test,3,5))
     
print("N = 4, D = 1, E = ", r_forest(X,Y, X_test,Y_test, 4,1))
print("N = 4, D = 2, E = ", r_forest(X,Y, X_test,Y_test, 4,2))
print("N = 4, D = 3, E = ", r_forest(X,Y, X_test, Y_test,4,3))
print("N = 4, D = 4, E = ", r_forest(X,Y, X_test, Y_test,4,4))
print("N = 4, D = 5, E = ", r_forest(X,Y, X_test, Y_test,4,5))  

print("N = 5, D = 1, E = ", r_forest(X,Y, X_test, Y_test,5,1))
print("N = 5, D = 2, E = ", r_forest(X,Y, X_test,Y_test, 5,2))
print("N = 5, D = 3, E = ", r_forest(X,Y, X_test,Y_test, 5,3))
print("N = 5, D = 4, E = ", r_forest(X,Y, X_test, Y_test,5,4))
print("N = 5, D = 5, E = ", r_forest(X,Y, X_test, Y_test,5,5))

#Create lists for plot
N_list = [1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,4,4,4,4,4,5,5,5,5,5]
D_list = [1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5]
E_list = [0.46,0.22,0.06,.08,0.06,0.42,0.06,.06,0.1,.08,.06,.06,.1,.06,.06,
          .3,.12,.04,.14,.06,.06,.16,.06,.16,.14]

#3d Plot
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')
ax.scatter(N_list, D_list, E_list)
ax.set_xlabel('# of trees')
ax.set_ylabel('Depth of trees')
ax.set_zlabel('Error Rate')

plt.show()
            

print("Question 2")

#Optimal N & D

prediction = p_forest(X,Y, X_test,Y_test, 5,4)

#Function for confusion matrix

def confusion (x,y):
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    i=0
    for e in x: 
        if x[i] == "Green":
            if x[i] == y[i]:
                tp = tp +1
            else:
                fp = fp +1
        else:
            if x[i] == y[i]:
                tn = tn + 1
            else: 
                fn = fn +1
        i = i+1
    return("Confusion:  TP", tp, "FP", fp, "TN", tn, "FN", fn)



print("Confusion matrix is ", confusion(Y_test, prediction))

print("Question 4:")

#Function for strategy

def strategy(x,a):
    value = 100
    z = 0
    for e in a:
        if e == "Green":
            value = value + ((value * x[z])/100)
        z = z + 1
    return (value)

rate = np.array(FDX_2016[["Return"]].values.ravel())

print("The strategy value is ", strategy(rate, prediction) )

#calculate buy and hold
buy_hold = []
buy_hold_value = 100
i = 0
for e in rate:
    buy_hold_value = buy_hold_value + (buy_hold_value * (e/100))
    buy_hold.append(buy_hold_value)
    i = i + 1

print("The buy and hold value is ", buy_hold[-1])


