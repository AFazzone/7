# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 12:52:26 2020

@author: alf11
"""

from scipy . stats import f as fisher_f
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib . pyplot as plt
from matplotlib . ticker import MaxNLocator
from sklearn . metrics import mean_squared_error , r2_score
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import svm, datasets
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error 



# Import CSV
FDX_data = pd.read_csv("FDX.csv") 


# Create Dataframes
FDX_df  = pd.DataFrame(FDX_data)


#Filter FDX dataframe by year/month
FDX_2018 = FDX_df[FDX_df["Year"].isin([2018])]
jan18 = FDX_2018[FDX_2018["Month"].isin([1])]
feb18 = FDX_2018[FDX_2018["Month"].isin([2])]
mar18 = FDX_2018[FDX_2018["Month"].isin([3])]
apr18 = FDX_2018[FDX_2018["Month"].isin([4])]
may18 = FDX_2018[FDX_2018["Month"].isin([5])]
jun18 = FDX_2018[FDX_2018["Month"].isin([6])] 
july18 = FDX_2018[FDX_2018["Month"].isin([7])]
aug18 = FDX_2018[FDX_2018["Month"].isin([8])]
sept18 = FDX_2018[FDX_2018["Month"].isin([9])]
oct18 = FDX_2018[FDX_2018["Month"].isin([10])]
nov18 = FDX_2018[FDX_2018["Month"].isin([11])]
dec18 = FDX_2018[FDX_2018["Month"].isin([12])]

#Filter by price

jan18_y = jan18["Close"].tolist()
feb18_y	= feb18["Close"].tolist()
mar18_y	= mar18["Close"].tolist()
apr18_y	= apr18["Close"].tolist()
may18_y	= may18["Close"].tolist()
jun18_y	= jun18["Close"].tolist()
july18_y = july18["Close"].tolist()
aug18_y	= aug18["Close"].tolist()
sept18_y= sept18["Close"].tolist()
oct18_y	= oct18["Close"].tolist()
nov18_y	= nov18["Close"].tolist()
dec18_y	= dec18["Close"].tolist()



FDX_2019 = FDX_df[FDX_df["Year"].isin([2019])]
jan19 = FDX_2019[FDX_2019["Month"].isin([1])]
feb19 = FDX_2019[FDX_2019["Month"].isin([2])]
mar19 = FDX_2019[FDX_2019["Month"].isin([3])]
apr19 = FDX_2019[FDX_2019["Month"].isin([4])]
may19 = FDX_2019[FDX_2019["Month"].isin([5])]
jun19 = FDX_2019[FDX_2019["Month"].isin([6])] 
july19 = FDX_2019[FDX_2019["Month"].isin([7])]
aug19 = FDX_2019[FDX_2019["Month"].isin([8])]
sept19 = FDX_2019[FDX_2019["Month"].isin([9])]
oct19 = FDX_2019[FDX_2019["Month"].isin([10])]
nov19 = FDX_2019[FDX_2019["Month"].isin([11])]
dec19 = FDX_2019[FDX_2019["Month"].isin([12])]



jan19_y = jan19["Close"].tolist()
feb19_y	= feb19["Close"].tolist()
mar19_y	= mar19["Close"].tolist()
apr19_y	= apr19["Close"].tolist()
may19_y	= may19["Close"].tolist()
jun19_y	= jun19["Close"].tolist()
july19_y = july19["Close"].tolist()
aug19_y	= aug19["Close"].tolist()
sept19_y= sept19["Close"].tolist()
oct19_y	= oct19["Close"].tolist()
nov19_y	= nov19["Close"].tolist()
dec19_y	= dec19["Close"].tolist()



#Find the number of days
def days (x):
    y = [*range(len(x))]
    return (y)

#Linear Equation function
def linear(x,y):
    degree = 1
    weights = np. polyfit (x,y,degree )
    model = np. poly1d (weights)
    predicted = model (x)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(rmse)

linear(days(jan18_y),jan18_y)

#Iterates trough a month splitting on differet day, returning the sums of SSE in a list
def find_break(x,y):
    i = 2
    SSE_list = []
    for e in x:
        if e < (len(x)-2):
            a = linear(x[i:], y[i:])
            b = linear(x[:i], y[:i])
            c = a +b
            SSE_list.append(c)
        i = i +1
    return(SSE_list.index(min(SSE_list)))

#Print the index of the break day
print("Jan 2018 Break Day", find_break(days(jan18_y), jan18_y)+2)
print("Feb 2018 Break Day", find_break(days(feb18_y), feb18_y)+2)
print("Mar 2018 Break Day", find_break(days(mar18_y), mar18_y)+2)
print("April 2018 Break Day", find_break(days(apr18_y), apr18_y)+2)
print("May 2018 Break Day", find_break(days(may18_y), may18_y)+2)
print("June 2018 Break Day", find_break(days(jun18_y), jun18_y)+2)
print("July 2018 Break Day", find_break(days(july18_y), july18_y)+2)
print("Aug 2018 Break Day", find_break(days(aug18_y), aug18_y)+2)
print("Sept 2018 Break Day", find_break(days(sept18_y), sept18_y)+2)
print("Oct 2018 Break Day", find_break(days(oct18_y), oct18_y)+2)
print("Nov 2018 Break Day", find_break(days(nov18_y), nov18_y)+2)
print("Dec 2018 Break Day", find_break(days(dec18_y), dec18_y)+2)

print("Jan 2019 Break Day", find_break(days(jan19_y), jan19_y)+2)
print("Feb 2019 Break Day", find_break(days(feb19_y), feb19_y)+2)
print("Mar 2019 Break Day", find_break(days(mar19_y), mar19_y)+2)
print("April 2019 Break Day", find_break(days(apr19_y), apr19_y)+2)
print("May 2019 Break Day", find_break(days(may19_y), may19_y)+2)
print("June 2019 Break Day", find_break(days(jun19_y), jun19_y)+2)
print("July 2019 Break Day", find_break(days(july19_y), july19_y)+2)
print("Aug 2019 Break Day", find_break(days(aug19_y), aug19_y)+2)
print("Sept 2019 Break Day", find_break(days(sept19_y), sept19_y)+2)
print("Oct 2019 Break Day", find_break(days(oct19_y), oct19_y)+2)
print("Nov 2019 Break Day", find_break(days(nov19_y), nov19_y)+2)
print("Dec 2019 Break Day", find_break(days(dec19_y), dec19_y)+2)



 #Find the F statistic subtracting the two subsets from the original
def f_stat (x,y,z):
    a = linear(x, y)
    b = linear(x[:z], y[:z])
    c = linear(x[z:],y[z:])   
    return (a-(b+c))
    

#Calculate f_stat over L, dividing L by the break day

jan18_f = f_stat(days(jan18_y),jan18_y,13)
feb18_f = f_stat(days(feb18_y),feb18_y,2)
mar18_f = f_stat(days(mar18_y),mar18_y,15)
apr18_f = f_stat(days(apr18_y),apr18_y,20)
may18_f = f_stat(days(may18_y),may18_y,21)
jun18_f = f_stat(days(may18_y),may18_y,10)
july18_f = f_stat(days(july18_y),july18_y,20)
aug18_f = f_stat(days(aug18_y),aug18_y,22)
sept18_f = f_stat(days(sept18_y),sept18_y,10)
oct18_f = f_stat(days(oct18_y),oct18_y,21)
nov18_f = f_stat(days(nov18_y),nov18_y,20)
dec18_f = f_stat(days(dec18_y),dec18_y,15)


jan19_f = f_stat(days(jan19_y),jan19_y,2)
feb19_f = f_stat(days(feb19_y),feb19_y,2)
mar19_f = f_stat(days(mar19_y),mar19_y,20)
apr19_f = f_stat(days(apr19_y),apr19_y,18)
may19_f = f_stat(days(may19_y),may19_y,2)
jun19_f = f_stat(days(may19_y),may19_y,16)
july19_f = f_stat(days(july19_y),july19_y,20)
aug19_f = f_stat(days(aug19_y),aug19_y,20)
sept19_f = f_stat(days(sept19_y),sept19_y,11)
oct19_f = f_stat(days(oct19_y),oct19_y,21)
nov19_f = f_stat(days(nov19_y),nov19_y,18)
dec19_f = f_stat(days(dec19_y),dec19_y,12)


#Print P Values

               
print("Jan 2018 P Values", fisher_f.cdf(jan18_f,2,(len(jan18_y)-4)))
print("Feb 2018 P Values", fisher_f.cdf(feb18_f,2,(len(feb18_y)-4)))
print("Mar 2018 P Values", fisher_f.cdf(mar18_f,2,(len(mar18_y)-4)))
print("April 2018 P Values", fisher_f.cdf(apr18_f,2,(len(apr18_y)-4)))
print("May 2018 P Values", fisher_f.cdf(may18_f,2,(len(may18_y)-4)))
print("June 2018 P Values", fisher_f.cdf(jun18_f,2,(len(jun18_y)-4)))
print("July 2018 P Values", fisher_f.cdf(july18_f,2,(len(july18_y)-4)))
print("Aug 2018 P Values", fisher_f.cdf(aug18_f,2,(len(aug18_y)-4)))
print("Sept 2018 P Values", fisher_f.cdf(sept18_f,2,(len(sept18_y)-4)))
print("Oct 2018 P Values", fisher_f.cdf(oct18_f,2,(len(oct18_y)-4)))
print("Nov 2018 P Values", fisher_f.cdf(nov18_f,2,(len(nov18_y)-4)))
print("Dec 2018 P Values", fisher_f.cdf(dec18_f,2,(len(dec18_y)-4)))

print("Jan 2019 P Values", fisher_f.cdf(jan19_f,2,(len(jan19_y)-4)))
print("Feb 2019 P Values", fisher_f.cdf(feb19_f,2,(len(feb19_y)-4)))
print("Mar 2019 P Values", fisher_f.cdf(mar19_f,2,(len(mar19_y)-4)))
print("April 2019 P Values", fisher_f.cdf(apr19_f,2,(len(apr19_y)-4)))
print("May 2019 P Values", fisher_f.cdf(may19_f,2,(len(may19_y)-4)))
print("June 2019 P Values", fisher_f.cdf(jun19_f,2,(len(jun19_y)-4)))
print("July 2019 P Values", fisher_f.cdf(july19_f,2,(len(july19_y)-4)))
print("Aug 2019 P Values", fisher_f.cdf(aug19_f,2,(len(aug19_y)-4)))
print("Sept 2019 P Values", fisher_f.cdf(sept19_f,2,(len(sept19_y)-4)))
print("Oct 2019 P Values", fisher_f.cdf(oct19_f,2,(len(oct19_y)-4)))
print("Nov 2019 P Values", fisher_f.cdf(nov19_f,2,(len(nov19_y)-4)))
print("Dec 2019 P Values", fisher_f.cdf(dec19_f,2,(len(dec19_y)-4)))
            
            






