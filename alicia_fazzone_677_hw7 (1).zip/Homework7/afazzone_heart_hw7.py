# -*- coding: utf-8 -*-
"""
Created on Wed Nov  4 22:20:08 2020

@author: alf11
"""
import math
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib . pyplot as plt
from matplotlib . ticker import MaxNLocator
from sklearn . metrics import mean_squared_error , r2_score
from matplotlib.backends.backend_pdf import PdfPages
from sklearn.linear_model import LogisticRegression
from sklearn.linear_model import LinearRegression
from sklearn import svm, datasets
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix
from sklearn.metrics import mean_squared_error
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error 




#Question 1

# Import CSV
Heart_data = pd.read_csv("heart_failure_clinical_records_dataset.csv") 

#Put into dataframe
heart_df  = pd.DataFrame(Heart_data)

#Divide by death event
heart_0 = heart_df[heart_df["DEATH_EVENT"].isin([0])]
heart_1 = heart_df[heart_df["DEATH_EVENT"].isin([1])]


#Add sub categories
sub_heart_0 = heart_0[['creatinine_phosphokinase', 'serum_creatinine',
                      'serum_sodium', 'platelets']]

sub_heart_1 = heart_1[["creatinine_phosphokinase", "serum_creatinine",
                      "serum_sodium", "platelets"]]

#Get Correlation
df_0_corr = sub_heart_0.corr()
df_1_corr = sub_heart_1.corr()

#Plot Correlation
sns.heatmap(df_0_corr, annot=True)
plt.title('Survivors')
df_0_corr.style.background_gradient(cmap='coolwarm').set_precision(2)
#Print to pdf
plt.savefig('DF_0.pdf')
plt.show()


sns.heatmap(df_1_corr, annot=True)
df_1_corr.style.background_gradient(cmap='coolwarm').set_precision(2)
plt.title('Deceased')
#Print to pdf
plt.savefig('DF_1.pdf')
plt.show()


# Question 2
#Group 1 splint into alive/deceased for my variables
group1_0 = heart_0[['creatinine_phosphokinase','platelets']]

group1_1 = heart_1[['creatinine_phosphokinase','platelets']]



#Split Alive into train and test
train, test = train_test_split(group1_0, test_size=0.5, random_state=123)


#Define Dependent and independent variables
x_train = train['creatinine_phosphokinase']
y_train = train['platelets']      
x_test  = test['creatinine_phosphokinase']
y_test  = test['platelets']     


#Linear Equation function
def linear(x,y,z):
    degree = 1
    weights = np. polyfit (x,y,degree )
    model = np. poly1d (weights)
    predicted = model (x)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(model, rmse, predicted)

# Quadratic function
def quadratic(x,y,z):
    degree = 2
    weights = np. polyfit (x,y,degree )
    model = np. poly1d (weights)
    predicted = model (x)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(model, rmse, predicted)

#Cubic Function
def cubic(x,y,z):
    degree = 3
    weights = np. polyfit (x,y,degree )
    model = np. poly1d (weights)
    predicted = model (z)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(model,rmse, predicted)

#Log X Function
def log_x (x,y,z):
    weights = np. polyfit (np.log(x),y,1)
    model = np. poly1d (weights)
    predicted = model (z)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(model,rmse, predicted)

#Log X/Y function
def log_x_y (x,y,z):
    weights = np. polyfit (np.log(x),np.log(y),1)
    model = np. poly1d (weights)
    predicted = model (z)
    rmse = np. sqrt ( mean_squared_error (y, predicted ))
    r2 = r2_score (y, predicted )
    return(model,rmse, predicted)

        
#Run Functions for alive 
model1_0, rmse1_0, pred1_0 = linear(x_train, y_train, x_test[1:])
model2_0, rmse2_0, pred2_0 = quadratic(x_train, y_train, x_test[1:])
model3_0, rmse3_0, pred3_0 = cubic(x_train, y_train, x_test[1:])
model4_0, rmse4_0, pred4_0 = log_x(x_train, y_train, x_test[1:])
model5_0, rmse5_0, pred5_0 = log_x_y(x_train, y_train, x_test[1:])

    
print("Model 1 alive is", model1_0, "SSE is ", rmse1_0)
print("Model 2 alive is", model2_0, "SSE is ", rmse2_0)
print("Model 3 alive is", model3_0, "SSE is ", rmse3_0)
print("Model 4 alive is", model4_0, "SSE is ", rmse4_0)
print("Model 5 alive is", model5_0, "SSE is ", rmse5_0)


#Functiom for linear alive

def alive_lin (x):
    predicted = []
    for i in x:
        y = (-3.619*i)+ 2.637
        predicted.append(y)
    return(predicted)

predicted1_0 = alive_lin(x_test)



def alive_quad (x):
    predicted = []
    for i in x:
        y = (-0.02583 *(x**2) )+ (54.97*i) + 2.523
        predicted.append(y)
    return(predicted)

predicted2_0 = alive_quad(x_test)
y_test = y_test.tolist()


#print(predicted2_0)
#print(y_test)

# Calculation of Sum of Squared Error  
#print("SSE Alive model2", mean_squared_error(y_test, predicted2_0))

#Plot values
b1 = plt.scatter(x_test, y_test, c='blue')
b2 = plt.scatter(x_test[1:], pred1_0, c='pink')
b3 = plt.scatter(x_test[1:], pred2_0, c='black')
b4 = plt.scatter(x_test[1:], pred3_0, c='red')
plt.legend((b1,b2,b3,b4), ("True", "Linear", "Quad", "Cubic"))
plt.title('Alive')
plt.xlabel('CPK')
plt.ylabel('platelets')
plt.savefig('ScatterPlot_05.png')
plt.show()

#Repeat for deceased:
train1, test1 = train_test_split(group1_1, test_size=0.5, random_state=123)


x_train1 = train1['creatinine_phosphokinase']
y_train1 = train1['platelets']      
x_test1  = test1['creatinine_phosphokinase']
y_test1  = test1['platelets']     


model1_1, rmse1_1, pred1_1 = linear(x_train1, y_train1, x_test1)
model2_1, rmse2_1, pred2_1 = quadratic(x_train1, y_train1, x_test1)
model3_1, rmse3_1, pred3_1 = cubic(x_train1, y_train1, x_test1)
model4_1, rmse4_1, pred4_1 = log_x(x_train1, y_train1, x_test1)
model5_1, rmse5_1, pred5_1 = log_x_y(x_train1, y_train1, x_test1)
    
print("Model 1 deceased is", model1_1, "SSE is ", rmse1_1)
print("Model 2 deceased is", model2_1, "SEE is", rmse2_1 )
print("Model 3 deceased is", model3_1, "SSE is", rmse3_1)
print("Model 4 deceased is", model4_1, "SSE is", rmse4_1)
print("Model 5 deceased is", model5_1, "SSE is", rmse5_1)

#Plot values
a1 = plt.scatter(x_test1, y_test1, c='purple')
a2 = plt.scatter(x_test1, pred1_1, c='blue')
a3 = plt.scatter(x_test1, pred2_1, c='green')
a4 = plt.scatter(x_test1, pred3_1, c='yellow')

plt.title('Deceased')
plt.legend((a1,a2,a3,a4), ("True", "Linear", "Quad", "Cubic"))
plt.xlabel('CPK')
plt.ylabel('platelets')
plt.savefig('ScatterPlot_05.png')
plt.show()


