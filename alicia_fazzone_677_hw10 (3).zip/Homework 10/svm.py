# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 12:46:34 2020

@author: alf11
"""


import pandas as pd
import numpy as np
from sklearn import svm
from sklearn . preprocessing import StandardScaler
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, classification_report, confusion_matrix

# Import CSV
FDX_weeks = pd.read_csv("FDX_Weeks_labels.csv") 

# Create Dataframes
FDX_weeks_df  = pd.DataFrame(FDX_weeks)

#create test  and train sets
FDX_2015 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2015])]
FDX_2016 = FDX_weeks_df[FDX_weeks_df["Year"].isin([2016])]


X = np.array(FDX_2015[["mean_return", "volatility"]].values.ravel())
Y = np.array(FDX_2015[["Label"]].values.ravel())

X = X.reshape(50,-1)
scaler = StandardScaler ()
scaler .fit(X)
X = scaler . transform (X)


X_test = np.array(FDX_2016[["mean_return", "volatility"]].values.ravel())
Y_test = np.array(FDX_2016[["Label"]].values.ravel())

X_test = X_test.reshape(50,-1)
 
#Run linear classifier
svm_classifier = []
svm_classifier = svm .SVC( kernel ='linear')
svm_classifier . fit (X,Y)
new_x = scaler . transform (np. asmatrix ([6 , 160]))
predicted1 = svm_classifier . predict (X_test)
accuracy1 = svm_classifier . score (X, Y)
cm = confusion_matrix(Y_test, predicted1)



#Run Gausian Classifier
svm_classifier = svm .SVC( kernel ='rbf')
svm_classifier . fit (X,Y)
new_x = scaler . transform (np. asmatrix ([6 , 160]))
predicted2 = svm_classifier . predict (X_test)
accuracy2 = svm_classifier . score (X, Y)

#Run Poly Degree 2 classifier

svm_classifier = svm .SVC( kernel ='poly', degree =2)
svm_classifier . fit (X,Y)
new_x = scaler . transform (np. asmatrix ([6 , 160]))
predicted = svm_classifier . predict (X_test)
accuracy3 = svm_classifier . score (X, Y)




#Function for confusion matrix
def confusion (x,y):
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    i=0
    for e in x: 
        if x[i] == "Green":
            if x[i] == y[i]:
                tp = tp +1
            else:
                fp = fp +1
        else:
            if x[i] == y[i]:
                tn = tn + 1
            else: 
                fn = fn +1
        i = i+1
    return("Confusion:  TP", tp, "FP", fp, "TN", tn, "FN", fn)



#Function for strategy

def strategy(x,a):
    value = 100
    z = 0
    for e in a:
        if e == "Green":
            value = value + ((value * x[z])/100)
        z = z + 1
    return (value)

rate = np.array(FDX_2016[["Return"]].values.ravel())

#calculate buy and hold
buy_hold = []
buy_hold_value = 100
i = 0
for e in rate:
    buy_hold_value = buy_hold_value + (buy_hold_value * (e/100))
    buy_hold.append(buy_hold_value)
    i = i + 1



print("Question 1 & 2")
print("The accuracy for linear is ", accuracy1)
print("The confusion matrix for linear is ", confusion(Y_test, predicted1))
print("Question 4")
print("The accuracy for Gaussian is ", accuracy2)
print("Question 5")
print("The accuracy for Poly degree 2 is ", accuracy3)
print("Question 6")
print("The strategy value is ", strategy(rate, predicted1) )
print("The buy and hold value is ", buy_hold[-1])


